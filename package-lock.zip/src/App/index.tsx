import React, {
  FC, useState, useEffect, useCallback, useMemo,
} from 'react'
import styles from './styles.module.scss'
import { TypingPlace } from '../components/TypingPlace'
import { Interactive } from '../components/Interactive'
import { Statistics } from '../components/Statistics'
import { useDebounce } from '../utils/useDebounce'

let timeout: NodeJS.Timeout

export const App: FC = () => {
  const [bestSpeed, setBestSpeed] = useState(0)
  const [alarm, setAlarm] = useState('')
  const [characters, setCharacters] = useState(localStorage.getItem('characters') ?? '500')
  const [value, setValue] = useState('')
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [isEng, setIsEng] = useState(localStorage.getItem('isEng') === 'true')
  const [isStarted, setIsStarted] = useState(false)
  const [misspelledWords, setMisspelledWords] = useState(0)
  const [time, setTime] = useState({ sec: 0, min: 0 })

  const charactersDebounce: string = useDebounce<string>(characters, 500)

  const reset = useCallback(() => {
    setText('')
    setValue('')
    setIsStarted(false)
    setTime({ sec: 0, min: 0 })
    setMisspelledWords(0)
  }, [])

  const toggleLang = useCallback(() => {
    setIsEng((prev) => !prev)
    reset()
  }, [reset])

  const getText = useCallback(() => {
    setLoading(true)

    clearTimeout(timeout)

    const api = `https://${isEng ? 'en' : 'ru'}.wikipedia.org/api/rest_v1/page/random/summary`
    fetch(api)
      .then((response) => response.json())
      .then((json: { extract: string, extract_html: string }) => {
        setText((prev) => `${prev}\n${json.extract}`.slice(0, +characters + 1))

        timeout = setTimeout(() => setLoading(false), 600)
      })
      .catch((e) => console.error(e))
  }, [characters, isEng])

  useEffect(() => {
    if (text.length < +characters + 1) getText()
  }, [text, characters, getText])

  useEffect(() => reset(), [charactersDebounce, reset])
  useEffect(() => localStorage.setItem('characters', String(charactersDebounce)), [charactersDebounce])
  useEffect(() => localStorage.setItem('isEng', String(isEng)), [isEng])

  const handleStart = () => {
    if (value) reset()

    setIsStarted(true)
  }
  const countWords = useMemo(
    () => text.replaceAll(/\n/g, '').split(' ').length,
    [text],
  )

  const exerciseTimeField = useMemo(
    () => `${time.min < 10 ? 0 : ''}${time.min}:${time.sec < 10 ? 0 : ''}${time.sec}`,
    [time.min, time.sec],
  )

  const misspelledWordsPercentField = useMemo(
    () => Math.round(((misspelledWords * 100) / countWords)),
    [misspelledWords, countWords],
  )

  const currentSpeedField = useMemo(
    () => ((time.sec / 60 + time.min)
      ? Math.round(+characters / (time.sec / 60 + time.min))
      : 0),
    [characters, time],
  )

  useEffect(() => {
    const bestTypingSpeed = localStorage.getItem('bestSpeed') ?? 0

    if (+bestTypingSpeed > currentSpeedField) {
      setBestSpeed(+bestTypingSpeed)
    }
    if ((+bestTypingSpeed < currentSpeedField) && (misspelledWordsPercentField <= 5) && (+characters >= 100)) {
      setBestSpeed(currentSpeedField)
      localStorage.setItem('bestSpeed', String(currentSpeedField))
    }
  }, [currentSpeedField, misspelledWordsPercentField, characters])

  useEffect(() => {
    if (misspelledWordsPercentField > 5 && +characters < 100) setAlarm(isEng
      ? 'Too many words with errors and too few characters. The result will not be recorded.'
      : 'Слишком много слов с ошибками и мало символов. Результат не будет записан.')
    else if (misspelledWordsPercentField > 5) setAlarm(isEng
      ? 'Too many words with errors. The result will not be recorded.'
      : 'Слишком много слов с ошибками. Результат не будет записан.')
    else if (+characters < 100) setAlarm(isEng
      ? 'Should be at least 100 characters. The result will not be recorded.'
      : 'Должно быть минимум 100 символов. Результат не будет записан.')
    else setAlarm('')
  }, [characters, misspelledWordsPercentField, isEng])

  return (
    <div className={styles.body}>
      <div className={styles.container}>
        <TypingPlace
          value={value}
          onChange={setValue}
          text={text}
          setMisspelledWords={setMisspelledWords}
          setTime={setTime}
          isStarted={isStarted}
          setIsStarted={setIsStarted}
          alarm={alarm}
          isEng={isEng}
        />
        <div className={styles.bottomWrapper}>
          <Interactive
            characters={characters}
            setCharacters={setCharacters}
            loading={loading}
            reset={reset}
            isEng={isEng}
            toggleLang={toggleLang}
            isStarted={isStarted}
            handleStart={handleStart}
          />
          <Statistics
            isStarted={isStarted}
            exerciseTime={exerciseTimeField}
            misspelledWords={misspelledWords}
            misspelledWordsPercent={misspelledWordsPercentField}
            currentSpeed={currentSpeedField}
            bestSpeed={bestSpeed}
            isEng={isEng}
          />
        </div>
      </div>
    </div>
  )
}
